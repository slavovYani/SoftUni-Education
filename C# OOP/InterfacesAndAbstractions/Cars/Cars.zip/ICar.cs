﻿
namespace Cars
{
    public interface ICar
    {
        public string Start();
        public string Stop();
    }
}
