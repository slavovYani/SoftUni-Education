﻿
namespace Raiding.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
