﻿
namespace Shapes
{
    using System;
    public class StartUp
    {
        static void Main(string[] args)
        {
            //    Shape item = new Circle(5);

            //    if(item is Shape shape )
            //    {
            //        Console.WriteLine(shape.Draw());
            //    }
            //    if(item is Rectangle)
            //    {
            //        Console.WriteLine(item.Draw());
            //    }


        }
    }
}
