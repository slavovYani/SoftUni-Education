﻿
namespace Vehicles.Models
{
    using Interfaces;
    public class Truck : IVehicle
    {
        private double fuelConsumption;

        public Truck(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumption { get => fuelConsumption; private set => fuelConsumption = value + 1.6; }

        public string Drive(double kilometers)
        {
            if (this.FuelQuantity - (this.FuelConsumption * kilometers) >= 0)
            {
                this.FuelQuantity -= this.FuelConsumption * kilometers;

                return $"Truck travelled {kilometers} km";
            }

            return $"Truck needs refueling";

        }

        public void Refuel(double fuel)
        {
            this.FuelQuantity += fuel * 0.95;
        }

        public override string ToString()
        {
            return $"Truck: {this.FuelQuantity:f2}";
        }
    }
}
