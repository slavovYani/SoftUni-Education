﻿
namespace Vehicles.Core
{
    using System;
    using System.Linq;

    using IO;
    using Vehicles.Models;
    using Vehicles.Models.Interfaces;

    public class Engine : IEngine
    {
        IReader reader;
        IWriter writer;

        public Engine(IReader reader, IWriter writer)
        {
            this.reader = reader;
            this.writer = writer;
        }

        public void Run()
        {
            string[] carInput = reader.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();
            string[] truckInput = reader.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

            IVehicle car = new Car(double.Parse(carInput[1]), double.Parse(carInput[2]));
            IVehicle truck = new Truck(double.Parse(truckInput[1]), double.Parse(truckInput[2]));

            int numberOfLines = int.Parse(reader.ReadLine());

            IVehicle vehicle;

            for (int i = 0; i < numberOfLines; i++)
            {
                string[] command = reader.ReadLine().Split();


                if (command[1] == "Car")
                {
                    vehicle = (Car)car;

                }
                else
                {
                    vehicle = (Truck)truck;
                }



                if (command[0] == "Drive")
                {
                    writer.WriteLine(vehicle.Drive(double.Parse(command[2])));

                }
                else
                {
                    vehicle.Refuel(double.Parse(command[2]));

                }


            }

            writer.WriteLine(car.ToString());
            writer.WriteLine(truck.ToString());
        }
    }
}
