﻿
namespace Vehicles.IO
{
    public interface IReader
    {
       public string ReadLine();
    }
}
