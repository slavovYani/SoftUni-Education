﻿

namespace WildFarm.Exceptions
{
    using System;
    public class NotEatableFoodException : Exception
    {
        
        public NotEatableFoodException(string message) : base(message)
        {

        }
    }
}
