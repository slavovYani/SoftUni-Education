﻿
namespace BorderControl.Core
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using BorderControl.Models.Interfaces;
    using IO;
    using Models;
    public class Engine : IEngine
    {
        private readonly IReader reader;
        private readonly IWriter writer;

        //private readonly Citizen citizen = new Citizen();  // trying to set instance of object without going trhrough empty constructor.
        //private readonly Robot robot = new Robot();

        private List<Citizen> citizens;     
        private List<Robot> robots;
       
        private IIdentity identity;
        private List<IIdentity> identities;
        

        public Engine(IReader reader, IWriter writer)
        {
            this.reader = reader;
            this.writer = writer;

            this.citizens = new List<Citizen>();
            this.robots = new List<Robot>();
            this.identities = new List<IIdentity>();
           
        }

        public void Run()
        {
            string command;

            while ((command = reader.ReadLine()) != "End")
            {
                SplitTheCommand(command, this.robots, this.citizens);


            }

            string lastDigits = reader.ReadLine();

            foreach (var identity in identities)
            {
                if (identity.ID.EndsWith(lastDigits)) writer.WriteLine(identity.ID);
            }
            

        }

        private void SplitTheCommand(string command, List<Robot> robots, List<Citizen> citizens)
        {
            string[] inputSplitted = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);

            if (inputSplitted.Length == 2)
            {
                
                IIdentity robot = new Robot(inputSplitted[0], inputSplitted[1]);

                identities.Add(robot);

                
            }
            else if (inputSplitted.Length == 3)
            {
                IIdentity citizen = new Citizen(inputSplitted[0], int.Parse(inputSplitted[1]), inputSplitted[2]);

                identities.Add(citizen);
            }
            else
            {
                throw new ArgumentException("Invalid input!");
            }
        }

       
    }
}
