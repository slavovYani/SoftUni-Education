﻿
namespace BorderControl.Models.Interfaces
{
    public interface ICitizen : IIdentity
    {
        public string Name { get;}
        public int Age { get; }
        
    }
}
