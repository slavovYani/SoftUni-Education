﻿
namespace BorderControl.Models.Interfaces
{
    public interface IIdentity
    {
        string ID { get; }
    }
}
