﻿
namespace BorderControl.Models.Interfaces
{
    public interface IBuyer
    {
        int BuyFood();
        public int Food { get;}
    }
}
