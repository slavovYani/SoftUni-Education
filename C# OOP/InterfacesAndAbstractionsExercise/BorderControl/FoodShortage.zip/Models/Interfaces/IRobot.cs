﻿
namespace BorderControl.Models.Interfaces
{
    public interface IRobot : IIdentity
    {
        public string Model { get;}
        
    }
}
