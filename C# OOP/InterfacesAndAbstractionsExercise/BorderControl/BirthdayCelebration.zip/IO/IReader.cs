﻿
namespace BorderControl.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
