﻿
namespace BorderControl.Core
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using BorderControl.Models.Interfaces;
    using IO;
    using Models;
    public class Engine : IEngine
    {
        private readonly IReader reader;
        private readonly IWriter writer;

        //private readonly Citizen citizen = new Citizen();  // trying to set instance of object without going trhrough empty constructor.
        //private readonly Robot robot = new Robot();

        private List<Citizen> citizens;
        private List<Robot> robots;

        private IIdentity identity;
        private List<IIdentity> identities;
        private IBirthDay birth;
        private List<IBirthDay> personsBirth;


        public Engine(IReader reader, IWriter writer)
        {
            this.reader = reader;
            this.writer = writer;

            this.citizens = new List<Citizen>();
            this.robots = new List<Robot>();
            this.identities = new List<IIdentity>();

            this.personsBirth = new List<IBirthDay>();

        }

        public void Run()
        {
            string command;

            while ((command = reader.ReadLine()) != "End")
            {
                SplitTheCommand(command, this.robots, this.citizens);


            }

            string lastDigits = reader.ReadLine();


            //int counter = 0;

            foreach (var identity in personsBirth)
            {
                if (identity.BirthDay.EndsWith(lastDigits))
                {
                    writer.WriteLine(identity.BirthDay);
                    //counter++;

                }

            }

            //if (counter == 0) writer.WriteLine("<empty output>");




        }
        //private void Print(IBirthDay birthDay, string lastDigits)
        //{
        //    if (birthDay.BirthDay.EndsWith(lastDigits)) writer.WriteLine(birthDay.BirthDay);

        //}
        private void SplitTheCommand(string command, List<Robot> robots, List<Citizen> citizens)
        {
            string[] inputSplitted = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);

            if (inputSplitted[0] == "Citizen")
            {

                IBirthDay citizen = new Citizen(inputSplitted[1], int.Parse(inputSplitted[2]), inputSplitted[3], inputSplitted[4]);

                personsBirth.Add(citizen);


            }
            else if (inputSplitted[0] == "Pet")
            {
                IBirthDay pet = new Pet(inputSplitted[1], inputSplitted[2]);


                personsBirth.Add(pet);

            }
            else if (inputSplitted[0] == "Robot")
            {
                IIdentity robot = new Robot(inputSplitted[1], inputSplitted[2]);


                identities.Add(robot);

            }
            else
            {
                throw new ArgumentException("Invalid input!");
            }
        }


    }
}
