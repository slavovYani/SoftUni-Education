﻿
namespace BorderControl.Models.Interfaces
{
    public interface ICitizen : IIdentity, IBirthDay
    {
        public string Name { get;}
        public int Age { get; }
        
        
    }
}
