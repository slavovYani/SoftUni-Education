﻿
namespace BorderControl.Models.Interfaces
{
    public interface IBirthDay
    {
        string BirthDay { get; }
    }
}
