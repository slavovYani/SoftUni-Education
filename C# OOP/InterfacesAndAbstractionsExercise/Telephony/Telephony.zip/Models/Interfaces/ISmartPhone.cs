﻿
namespace Telephony.Models.Interfaces
{
    public interface ISmartPhone : IStationaryPhone
    {
        string BrowseURL(string url);
    }
}
