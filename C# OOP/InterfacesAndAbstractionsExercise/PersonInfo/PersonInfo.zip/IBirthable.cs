﻿
using System.Net.NetworkInformation;

namespace PersonInfo
{
    public interface IBirthable
    {
        public string Birthdate { get; set; }
    }
}
