﻿
namespace _01.ClassBoxData
{
    public static class ExceptionMessage
    {
        public const string ValueIsLessThanZero = "{0} cannot be zero or negative.";
    }
}
