﻿namespace NavalVessels.Models
{
    using System;
    using Contracts;
    public class Battleship : Vessel, IBattleship
    {
        private const double INITIAL_ARMOR_THICKNESS = 300;
        private bool sonarMode;
        public Battleship(string name, double mainWeaponCaliber, double speed) : base(name, mainWeaponCaliber, speed, INITIAL_ARMOR_THICKNESS)
        {
            this.SonarMode = false;
        }

        public bool SonarMode
        {
            get => sonarMode;
            private set => sonarMode = value;
        }

        public override void RepairVessel()
        {
            if (ArmorThickness < 300)
            {
                this.ArmorThickness = INITIAL_ARMOR_THICKNESS;

            }

        }

        public void ToggleSonarMode()
        {
            if (!SonarMode)
            {
                sonarMode = true;
                this.MainWeaponCaliber += 40;
                this.Speed -= 5;

            }

            else
            {
                sonarMode = false;
                this.MainWeaponCaliber -= 40;
                this.Speed += 5;
            }

        }

        public override string ToString()
        {
            string text;

            text = (SonarMode) ? "ON" : "OFF";

            return (base.ToString() + Environment.NewLine + $" *Sonar mode: {text}").TrimEnd();
        }



    }
}