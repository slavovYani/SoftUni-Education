﻿
using System;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string nameOfClass, params string[] nameOfFields)
        {
            Type classType = Type.GetType(nameOfClass);
            

            FieldInfo[] fields = classType.GetFields(BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Static);
            StringBuilder sb = new StringBuilder();

            Object classInstance = Activator.CreateInstance(classType, new object[]{ });

            sb.AppendLine($"Class under investigation: {nameOfClass}");

            foreach (var field in fields.Where(f=>nameOfFields.Contains(f.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }

            return sb.ToString().Trim();
        }

        public void AnalyzeAccessModifiers(string className)
        {

        }
    }
}
