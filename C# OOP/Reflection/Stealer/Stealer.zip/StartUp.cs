﻿
namespace Stealer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Spy spy = new Spy();

            System.Console.WriteLine(spy.StealFieldInfo("Stealer.Hacker", "username", "password"));


        }
    }
    
}
