﻿
namespace CommandPattern.IO.Interfaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}
