﻿using System;

namespace _07.Tuple
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] input1 = Console.ReadLine().Split();
            string[] input2 = Console.ReadLine().Split();
            string[] input3 = Console.ReadLine().Split();

            Tuple<string, string> nameAndAdress = new Tuple<string, string>() 
            {
                Item1 = input1[0] + " " + input1[1],
                Item2=input1[2],    
            };

            Tuple<string, int> nameAndBeers = new Tuple<string, int>()
            {
                Item1 = input2[0],
                Item2 = int.Parse(input2[1])
            };

            Tuple<int, double> numbers = new Tuple<int, double>()
            {
                Item1 = int.Parse(input3[0]),
                Item2 = double.Parse(input3[1])
            };

            Console.WriteLine(nameAndAdress);
            Console.WriteLine(nameAndBeers);
            Console.WriteLine(numbers);


        }
    }
}
