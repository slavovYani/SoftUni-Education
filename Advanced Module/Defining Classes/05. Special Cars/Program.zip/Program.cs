﻿using System;
using System.Collections.Generic;
using CarManufacturer;

namespace _05._Special_Cars
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] tiresInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            List<Tire[]> tiresList = new List<Tire[]>();

            while (tiresInfo[0] != "No")
            {
                tiresList.Add(new Tire[4]
                {
                    new Tire(int.Parse(tiresInfo[0]),double.Parse(tiresInfo[1])),
                    new Tire(int.Parse(tiresInfo[2]),double.Parse(tiresInfo[3])),
                    new Tire(int.Parse(tiresInfo[4]),double.Parse(tiresInfo[5])),
                    new Tire(int.Parse(tiresInfo[6]),double.Parse(tiresInfo[7])),


                });


                tiresInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            }

            List<Engine> engines = new List<Engine>();

            string[] enginesInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            while (enginesInfo[0] != "Engines")
            {
                engines.Add(new Engine(int.Parse(enginesInfo[0]), double.Parse(enginesInfo[1])));


                enginesInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            }

            List<Car> cars = new List<Car>();

            string[] carsInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            int indexOfTires = 0;
            int indexOfEngine = 0;

            while (carsInfo[0] != "Show")
            {

                string make = carsInfo[0];
                string model = carsInfo[1];
                int year = int.Parse(carsInfo[2]);
                double fuelQuantity = double.Parse(carsInfo[3]);
                double fuelConsumption = double.Parse(carsInfo[4]);

                indexOfTires = int.Parse(carsInfo[6]);
                indexOfEngine = int.Parse(carsInfo[5]);
                cars.Add(new Car(make, model, year, fuelQuantity, fuelConsumption, engines[indexOfEngine], tiresList[indexOfTires])); // списък по 4тири гуми
                carsInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            }
            indexOfTires = 0;

            foreach (var car in cars)
            {

                double sumOfTirePressure = car.SumOfTirePressure(indexOfTires, tiresList);

                car.Drive(sumOfTirePressure, car);

                indexOfTires++;
            }


        }
    }
}
