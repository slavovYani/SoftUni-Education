﻿using System;

namespace GenericCountMethod
{
    public class Program
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());

            Box<string> box = new Box<string>();

            for (int i = 0; i < lines; i++)
            {
                box.Items.Add(Console.ReadLine());
            }

            string elementToCompare = Console.ReadLine();

            Console.WriteLine(box.Compare(elementToCompare));
        }
    }
}
